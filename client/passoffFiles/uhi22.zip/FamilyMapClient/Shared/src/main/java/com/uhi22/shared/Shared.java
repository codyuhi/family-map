package com.uhi22.shared;

public class Shared {
}
